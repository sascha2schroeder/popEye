# Setup of experiments in Exeriment Builder 

An example script how to set up your experiment in Experiment Builder can be found 
[here.](ExperimentBuilder.ebz)
